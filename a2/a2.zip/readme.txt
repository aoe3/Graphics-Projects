Andrew Eccles (aoe3)
Daisy Zheng (dhz9)