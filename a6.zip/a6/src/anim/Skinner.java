package anim;

public class Skinner {

}
